from django import forms
from django.core.exceptions import ValidationError
from datetime import date

from MaterialsApp.models import MaterielMedical

class MaterielMedicalForm(forms.ModelForm):
    # Champ personnalisé pour la partie numérique de la référence
    reference_number = forms.IntegerField(
        label="Numéro de référence",
        min_value=1,
        help_text="Saisissez uniquement des chiffres (ex: 12345)",
        widget=forms.NumberInput(attrs={
            'placeholder': '12345',
            'class': 'form-control'
        })
    )
    
    class Meta:
        model = MaterielMedical
        fields = [
            'Nom', 'Type', 'Etat', 'Quantite', 
            'PrixAchat', 'DateAcquisition', 'DateExpiration'
        ]
        widgets = {
            'DateAcquisition': forms.DateInput(attrs={'type': 'date'}),
            'DateExpiration': forms.DateInput(attrs={'type': 'date'}),
        }
    
    def clean_DateExpiration(self):
        date_expiration = self.cleaned_data.get('DateExpiration')
        if date_expiration and date_expiration < date.today():
            raise ValidationError("La date d'expiration ne peut pas être dans le passé. Veuillez fournir une date valide.")
        return date_expiration
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Si on modifie un objet existant, pré-remplir le champ numérique
        if self.instance and self.instance.pk:
            ref_value = self.instance.Reference
            if ref_value.startswith('REF-'):
                try:
                    number_part = ref_value.replace('REF-', '')
                    self.fields['reference_number'].initial = int(number_part)
                except ValueError:
                    pass
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        # Construire la référence complète avec le préfixe
        ref_number = self.cleaned_data['reference_number']
        instance.Reference = f"REF-{ref_number}"
        
        if commit:
            instance.save()
        return instance