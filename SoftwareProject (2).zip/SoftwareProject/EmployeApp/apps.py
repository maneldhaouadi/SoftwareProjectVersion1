from django.apps import AppConfig


class EmployeappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EmployeApp'
