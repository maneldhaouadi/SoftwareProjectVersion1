from django.apps import AppConfig


class MaterialsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MaterialsApp'
